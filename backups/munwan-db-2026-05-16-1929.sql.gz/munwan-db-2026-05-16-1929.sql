--
-- PostgreSQL database dump
--

\restrict BD9TOnf9hZYZwMK5j2mIn2U5UkiWeyeAVRPWvbwj4rkuDr2bHYrsMTnmP59oCCP

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_user_id_c564eba6_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_content_type_id_c4bce8eb_fk_django_co;
ALTER TABLE IF EXISTS ONLY public.core_safaripricing DROP CONSTRAINT IF EXISTS core_safaripricing_vehicle_id_f8424545_fk_core_vehicle_id;
ALTER TABLE IF EXISTS ONLY public.core_safaripricing DROP CONSTRAINT IF EXISTS core_safaripricing_destination_id_52877daa_fk;
ALTER TABLE IF EXISTS ONLY public.core_review DROP CONSTRAINT IF EXISTS core_review_booking_id_bd813940_fk_core_booking_id;
ALTER TABLE IF EXISTS ONLY public.core_paymentlog DROP CONSTRAINT IF EXISTS core_paymentlog_booking_id_8ce3d5e2_fk_core_booking_id;
ALTER TABLE IF EXISTS ONLY public.core_emailotp DROP CONSTRAINT IF EXISTS core_emailotp_user_id_fc31491f_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.core_booking DROP CONSTRAINT IF EXISTS core_booking_vehicle_id_ca3eca18_fk_core_vehicle_id;
ALTER TABLE IF EXISTS ONLY public.core_booking DROP CONSTRAINT IF EXISTS core_booking_user_id_55d9bfa8_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.core_booking_safari_destinations DROP CONSTRAINT IF EXISTS core_booking_safari_desti_safaridestination_id_f431b6aa_fk;
ALTER TABLE IF EXISTS ONLY public.core_booking_safari_destinations DROP CONSTRAINT IF EXISTS core_booking_safari__booking_id_dc125a7e_fk_core_book;
ALTER TABLE IF EXISTS ONLY public.core_booking DROP CONSTRAINT IF EXISTS core_booking_parent_booking_id_33499372_fk_core_booking_id;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_user_id_6a12ed8b_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_group_id_97559544_fk_auth_group_id;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS auth_permission_content_type_id_2f476e4b_fk_django_co;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_group_id_b120cbf9_fk_auth_group_id;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissio_permission_id_84c5c92e_fk_auth_perm;
DROP INDEX IF EXISTS public.django_session_session_key_c0390e0f_like;
DROP INDEX IF EXISTS public.django_session_expire_date_a5c62663;
DROP INDEX IF EXISTS public.django_admin_log_user_id_c564eba6;
DROP INDEX IF EXISTS public.django_admin_log_content_type_id_c4bce8eb;
DROP INDEX IF EXISTS public.core_vehicle_slug_2bec56e2_like;
DROP INDEX IF EXISTS public.core_safaripricing_vehicle_id_f8424545;
DROP INDEX IF EXISTS public.core_safaripricing_destination_id_52877daa;
DROP INDEX IF EXISTS public.core_safaridestination_slug_fb4e83b3_like;
DROP INDEX IF EXISTS public.core_safaridestination_name_da9a987b_like;
DROP INDEX IF EXISTS public.core_paymentlog_booking_id_8ce3d5e2;
DROP INDEX IF EXISTS public.core_emailotp_user_id_fc31491f;
DROP INDEX IF EXISTS public.core_emailotp_email_20c81e6d_like;
DROP INDEX IF EXISTS public.core_emailotp_email_20c81e6d;
DROP INDEX IF EXISTS public.core_booking_vehicle_id_ca3eca18;
DROP INDEX IF EXISTS public.core_booking_user_id_55d9bfa8;
DROP INDEX IF EXISTS public.core_booking_safari_destinations_safaridestination_id_f431b6aa;
DROP INDEX IF EXISTS public.core_booking_safari_destinations_booking_id_dc125a7e;
DROP INDEX IF EXISTS public.core_booking_reference_9109c71f_like;
DROP INDEX IF EXISTS public.core_booking_parent_booking_id_33499372;
DROP INDEX IF EXISTS public.core_booking_invoice_number_a692a043_like;
DROP INDEX IF EXISTS public.core_booking_invoice_number_a692a043;
DROP INDEX IF EXISTS public.auth_user_username_6821ab7c_like;
DROP INDEX IF EXISTS public.auth_user_user_permissions_user_id_a95ead1b;
DROP INDEX IF EXISTS public.auth_user_user_permissions_permission_id_1fbb5f2c;
DROP INDEX IF EXISTS public.auth_user_groups_user_id_6a12ed8b;
DROP INDEX IF EXISTS public.auth_user_groups_group_id_97559544;
DROP INDEX IF EXISTS public.auth_permission_content_type_id_2f476e4b;
DROP INDEX IF EXISTS public.auth_group_permissions_permission_id_84c5c92e;
DROP INDEX IF EXISTS public.auth_group_permissions_group_id_b120cbf9;
DROP INDEX IF EXISTS public.auth_group_name_a6ea08ec_like;
ALTER TABLE IF EXISTS ONLY public.django_session DROP CONSTRAINT IF EXISTS django_session_pkey;
ALTER TABLE IF EXISTS ONLY public.django_migrations DROP CONSTRAINT IF EXISTS django_migrations_pkey;
ALTER TABLE IF EXISTS ONLY public.django_content_type DROP CONSTRAINT IF EXISTS django_content_type_pkey;
ALTER TABLE IF EXISTS ONLY public.django_content_type DROP CONSTRAINT IF EXISTS django_content_type_app_label_model_76bd3d3b_uniq;
ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_pkey;
ALTER TABLE IF EXISTS ONLY public.core_vehicle DROP CONSTRAINT IF EXISTS core_vehicle_slug_key;
ALTER TABLE IF EXISTS ONLY public.core_vehicle DROP CONSTRAINT IF EXISTS core_vehicle_pkey;
ALTER TABLE IF EXISTS ONLY public.core_supportticket DROP CONSTRAINT IF EXISTS core_supportticket_pkey;
ALTER TABLE IF EXISTS ONLY public.core_safaripricing DROP CONSTRAINT IF EXISTS core_safaripricing_pkey;
ALTER TABLE IF EXISTS ONLY public.core_safaripricing DROP CONSTRAINT IF EXISTS core_safaripricing_destination_id_vehicle_id_e1009c8e_uniq;
ALTER TABLE IF EXISTS ONLY public.core_safaridestination DROP CONSTRAINT IF EXISTS core_safaridestination_slug_key;
ALTER TABLE IF EXISTS ONLY public.core_safaridestination DROP CONSTRAINT IF EXISTS core_safaridestination_pkey;
ALTER TABLE IF EXISTS ONLY public.core_safaridestination DROP CONSTRAINT IF EXISTS core_safaridestination_name_key;
ALTER TABLE IF EXISTS ONLY public.core_review DROP CONSTRAINT IF EXISTS core_review_pkey;
ALTER TABLE IF EXISTS ONLY public.core_review DROP CONSTRAINT IF EXISTS core_review_booking_id_key;
ALTER TABLE IF EXISTS ONLY public.core_ratelimitentry DROP CONSTRAINT IF EXISTS core_ratelimitentry_pkey;
ALTER TABLE IF EXISTS ONLY public.core_ratelimitentry DROP CONSTRAINT IF EXISTS core_ratelimitentry_ip_address_action_fe93a6a4_uniq;
ALTER TABLE IF EXISTS ONLY public.core_paymentlog DROP CONSTRAINT IF EXISTS core_paymentlog_pkey;
ALTER TABLE IF EXISTS ONLY public.core_emailotp DROP CONSTRAINT IF EXISTS core_emailotp_pkey;
ALTER TABLE IF EXISTS ONLY public.core_booking_safari_destinations DROP CONSTRAINT IF EXISTS core_booking_safari_destinations_pkey;
ALTER TABLE IF EXISTS ONLY public.core_booking_safari_destinations DROP CONSTRAINT IF EXISTS core_booking_safari_dest_booking_id_safaridestina_af8d85b2_uniq;
ALTER TABLE IF EXISTS ONLY public.core_booking DROP CONSTRAINT IF EXISTS core_booking_reference_key;
ALTER TABLE IF EXISTS ONLY public.core_booking DROP CONSTRAINT IF EXISTS core_booking_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_user DROP CONSTRAINT IF EXISTS auth_user_username_key;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permissions_user_id_permission_id_14a6b632_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_user DROP CONSTRAINT IF EXISTS auth_user_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_user_id_group_id_94350c0c_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS auth_permission_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS auth_permission_content_type_id_codename_01ab375a_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_group DROP CONSTRAINT IF EXISTS auth_group_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_group_id_permission_id_0cd325b0_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_group DROP CONSTRAINT IF EXISTS auth_group_name_key;
DROP TABLE IF EXISTS public.django_session;
DROP TABLE IF EXISTS public.django_migrations;
DROP TABLE IF EXISTS public.django_content_type;
DROP TABLE IF EXISTS public.django_admin_log;
DROP TABLE IF EXISTS public.core_vehicle;
DROP TABLE IF EXISTS public.core_supportticket;
DROP TABLE IF EXISTS public.core_safaripricing;
DROP TABLE IF EXISTS public.core_safaridestination;
DROP TABLE IF EXISTS public.core_review;
DROP TABLE IF EXISTS public.core_ratelimitentry;
DROP TABLE IF EXISTS public.core_paymentlog;
DROP TABLE IF EXISTS public.core_emailotp;
DROP TABLE IF EXISTS public.core_booking_safari_destinations;
DROP TABLE IF EXISTS public.core_booking;
DROP TABLE IF EXISTS public.auth_user_user_permissions;
DROP TABLE IF EXISTS public.auth_user_groups;
DROP TABLE IF EXISTS public.auth_user;
DROP TABLE IF EXISTS public.auth_permission;
DROP TABLE IF EXISTS public.auth_group_permissions;
DROP TABLE IF EXISTS public.auth_group;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: munwan
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO munwan;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: munwan
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: munwan
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO munwan;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: munwan
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: munwan
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO munwan;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: munwan
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: munwan
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO munwan;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: munwan
--

CREATE TABLE public.auth_user_groups (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO munwan;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: munwan
--

ALTER TABLE public.auth_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: munwan
--

ALTER TABLE public.auth_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: munwan
--

CREATE TABLE public.auth_user_user_permissions (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO munwan;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: munwan
--

ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_booking; Type: TABLE; Schema: public; Owner: munwan
--

CREATE TABLE public.core_booking (
    id bigint NOT NULL,
    reference character varying(20) NOT NULL,
    first_name character varying(60) NOT NULL,
    last_name character varying(60) NOT NULL,
    email character varying(254) NOT NULL,
    phone character varying(30) NOT NULL,
    nationality character varying(60) NOT NULL,
    hire_type character varying(10) NOT NULL,
    with_driver boolean NOT NULL,
    pickup_location character varying(10) NOT NULL,
    hotel_address character varying(300) NOT NULL,
    dropoff_location character varying(300) NOT NULL,
    pickup_date date NOT NULL,
    pickup_time time without time zone NOT NULL,
    return_date date,
    return_time time without time zone,
    days smallint NOT NULL,
    base_price_usd numeric(10,2) NOT NULL,
    driver_fee_usd numeric(10,2) NOT NULL,
    total_usd numeric(10,2) NOT NULL,
    total_kes numeric(12,2) NOT NULL,
    total_eur numeric(10,2) NOT NULL,
    payment_method character varying(10) NOT NULL,
    payment_status character varying(10) NOT NULL,
    payment_ref character varying(200) NOT NULL,
    status character varying(12) NOT NULL,
    ip_address inet,
    user_agent text NOT NULL,
    notes text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    user_id integer,
    vehicle_id bigint NOT NULL,
    terms_accepted boolean NOT NULL,
    baby_seat boolean NOT NULL,
    payment_reminder_sent boolean NOT NULL,
    payment_attempt_at timestamp with time zone,
    transfer_direction character varying(4) NOT NULL,
    transfer_zone character varying(10) NOT NULL,
    transfer_car_type character varying(10) NOT NULL,
    transfer_destination character varying(120) NOT NULL,
    is_night_surcharge boolean NOT NULL,
    safari_breakdown jsonb,
    parent_booking_id bigint,
    invoice_number character varying(20) NOT NULL,
    invoice_issued_at timestamp with time zone,
    invoice_due_date date,
    company_name character varying(120) NOT NULL,
    company_kra_pin character varying(20) NOT NULL,
    company_address character varying(300) NOT NULL,
    CONSTRAINT core_booking_days_check CHECK ((days >= 0))
);


ALTER TABLE public.core_booking OWNER TO munwan;

--
-- Name: core_booking_id_seq; Type: SEQUENCE; Schema: public; Owner: munwan
--

ALTER TABLE public.core_booking ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_booking_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_booking_safari_destinations; Type: TABLE; Schema: public; Owner: munwan
--

CREATE TABLE public.core_booking_safari_destinations (
    id bigint NOT NULL,
    booking_id bigint NOT NULL,
    safaridestination_id bigint NOT NULL
);


ALTER TABLE public.core_booking_safari_destinations OWNER TO munwan;

--
-- Name: core_booking_safari_destinations_id_seq; Type: SEQUENCE; Schema: public; Owner: munwan
--

ALTER TABLE public.core_booking_safari_destinations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_booking_safari_destinations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_emailotp; Type: TABLE; Schema: public; Owner: munwan
--

CREATE TABLE public.core_emailotp (
    id bigint NOT NULL,
    email character varying(254) NOT NULL,
    code character varying(6) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    attempts smallint NOT NULL,
    verified_at timestamp with time zone,
    user_id integer,
    CONSTRAINT core_emailotp_attempts_check CHECK ((attempts >= 0))
);


ALTER TABLE public.core_emailotp OWNER TO munwan;

--
-- Name: core_emailotp_id_seq; Type: SEQUENCE; Schema: public; Owner: munwan
--

ALTER TABLE public.core_emailotp ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_emailotp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_paymentlog; Type: TABLE; Schema: public; Owner: munwan
--

CREATE TABLE public.core_paymentlog (
    id bigint NOT NULL,
    method character varying(10) NOT NULL,
    gateway_ref character varying(300) NOT NULL,
    amount_usd numeric(10,2) NOT NULL,
    status character varying(20) NOT NULL,
    raw_response text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    booking_id bigint NOT NULL
);


ALTER TABLE public.core_paymentlog OWNER TO munwan;

--
-- Name: core_paymentlog_id_seq; Type: SEQUENCE; Schema: public; Owner: munwan
--

ALTER TABLE public.core_paymentlog ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_paymentlog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_ratelimitentry; Type: TABLE; Schema: public; Owner: munwan
--

CREATE TABLE public.core_ratelimitentry (
    id bigint NOT NULL,
    ip_address inet NOT NULL,
    action character varying(30) NOT NULL,
    count integer NOT NULL,
    window_start timestamp with time zone NOT NULL,
    CONSTRAINT core_ratelimitentry_count_check CHECK ((count >= 0))
);


ALTER TABLE public.core_ratelimitentry OWNER TO munwan;

--
-- Name: core_ratelimitentry_id_seq; Type: SEQUENCE; Schema: public; Owner: munwan
--

ALTER TABLE public.core_ratelimitentry ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_ratelimitentry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_review; Type: TABLE; Schema: public; Owner: munwan
--

CREATE TABLE public.core_review (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    location character varying(100) NOT NULL,
    flag_emoji character varying(10) NOT NULL,
    rating smallint NOT NULL,
    text text NOT NULL,
    is_published boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    booking_id bigint,
    CONSTRAINT core_review_rating_check CHECK ((rating >= 0))
);


ALTER TABLE public.core_review OWNER TO munwan;

--
-- Name: core_review_id_seq; Type: SEQUENCE; Schema: public; Owner: munwan
--

ALTER TABLE public.core_review ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_review_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_safaridestination; Type: TABLE; Schema: public; Owner: munwan
--

CREATE TABLE public.core_safaridestination (
    id bigint NOT NULL,
    name character varying(80) NOT NULL,
    short_name character varying(40) NOT NULL,
    slug character varying(50) NOT NULL,
    description character varying(300) NOT NULL,
    distance_km smallint NOT NULL,
    recommended_days smallint NOT NULL,
    is_active boolean NOT NULL,
    "order" smallint NOT NULL,
    CONSTRAINT core_safaridestination_distance_km_check CHECK ((distance_km >= 0)),
    CONSTRAINT core_safaridestination_order_check CHECK (("order" >= 0)),
    CONSTRAINT core_safaridestination_recommended_days_check CHECK ((recommended_days >= 0))
);


ALTER TABLE public.core_safaridestination OWNER TO munwan;

--
-- Name: core_safaridestination_id_seq; Type: SEQUENCE; Schema: public; Owner: munwan
--

ALTER TABLE public.core_safaridestination ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_safaridestination_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_safaripricing; Type: TABLE; Schema: public; Owner: munwan
--

CREATE TABLE public.core_safaripricing (
    id bigint NOT NULL,
    price_usd numeric(8,2) NOT NULL,
    notes character varying(200) NOT NULL,
    destination_id bigint NOT NULL,
    vehicle_id bigint NOT NULL
);


ALTER TABLE public.core_safaripricing OWNER TO munwan;

--
-- Name: core_safaripricing_id_seq; Type: SEQUENCE; Schema: public; Owner: munwan
--

ALTER TABLE public.core_safaripricing ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_safaripricing_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_supportticket; Type: TABLE; Schema: public; Owner: munwan
--

CREATE TABLE public.core_supportticket (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(254) NOT NULL,
    phone character varying(30) NOT NULL,
    subject character varying(200) NOT NULL,
    message text NOT NULL,
    booking_ref character varying(20) NOT NULL,
    status character varying(10) NOT NULL,
    ip_address inet,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.core_supportticket OWNER TO munwan;

--
-- Name: core_supportticket_id_seq; Type: SEQUENCE; Schema: public; Owner: munwan
--

ALTER TABLE public.core_supportticket ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_supportticket_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_vehicle; Type: TABLE; Schema: public; Owner: munwan
--

CREATE TABLE public.core_vehicle (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(50) NOT NULL,
    category character varying(20) NOT NULL,
    badge character varying(10) NOT NULL,
    description character varying(200) NOT NULL,
    seats smallint NOT NULL,
    fuel character varying(20) NOT NULL,
    transmission character varying(20) NOT NULL,
    has_ac boolean NOT NULL,
    has_gps boolean NOT NULL,
    price_usd numeric(8,2) NOT NULL,
    price_kes numeric(10,2) NOT NULL,
    price_eur numeric(8,2) NOT NULL,
    driver_fee_usd numeric(8,2) NOT NULL,
    image character varying(100),
    is_available boolean NOT NULL,
    "order" smallint NOT NULL,
    transfer_car_type character varying(10) NOT NULL,
    CONSTRAINT core_vehicle_order_check CHECK (("order" >= 0)),
    CONSTRAINT core_vehicle_seats_check CHECK ((seats >= 0))
);


ALTER TABLE public.core_vehicle OWNER TO munwan;

--
-- Name: core_vehicle_id_seq; Type: SEQUENCE; Schema: public; Owner: munwan
--

ALTER TABLE public.core_vehicle ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_vehicle_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: munwan
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO munwan;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: munwan
--

ALTER TABLE public.django_admin_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: munwan
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO munwan;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: munwan
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: munwan
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO munwan;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: munwan
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: munwan
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO munwan;

--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: munwan
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: munwan
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: munwan
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add user	4	add_user
14	Can change user	4	change_user
15	Can delete user	4	delete_user
16	Can view user	4	view_user
17	Can add content type	5	add_contenttype
18	Can change content type	5	change_contenttype
19	Can delete content type	5	delete_contenttype
20	Can view content type	5	view_contenttype
21	Can add session	6	add_session
22	Can change session	6	change_session
23	Can delete session	6	delete_session
24	Can view session	6	view_session
25	Can add vehicle	7	add_vehicle
26	Can change vehicle	7	change_vehicle
27	Can delete vehicle	7	delete_vehicle
28	Can view vehicle	7	view_vehicle
29	Can add booking	8	add_booking
30	Can change booking	8	change_booking
31	Can delete booking	8	delete_booking
32	Can view booking	8	view_booking
33	Can add payment log	9	add_paymentlog
34	Can change payment log	9	change_paymentlog
35	Can delete payment log	9	delete_paymentlog
36	Can view payment log	9	view_paymentlog
37	Can add review	10	add_review
38	Can change review	10	change_review
39	Can delete review	10	delete_review
40	Can view review	10	view_review
41	Can add support ticket	11	add_supportticket
42	Can change support ticket	11	change_supportticket
43	Can delete support ticket	11	delete_supportticket
44	Can view support ticket	11	view_supportticket
45	Can add rate limit entry	12	add_ratelimitentry
46	Can change rate limit entry	12	change_ratelimitentry
47	Can delete rate limit entry	12	delete_ratelimitentry
48	Can view rate limit entry	12	view_ratelimitentry
49	Can add email otp	13	add_emailotp
50	Can change email otp	13	change_emailotp
51	Can delete email otp	13	delete_emailotp
52	Can view email otp	13	view_emailotp
53	Can add safari destination	14	add_safaridestination
54	Can change safari destination	14	change_safaridestination
55	Can delete safari destination	14	delete_safaridestination
56	Can view safari destination	14	view_safaridestination
57	Can add Safari price	15	add_safaripricing
58	Can change Safari price	15	change_safaripricing
59	Can delete Safari price	15	delete_safaripricing
60	Can view Safari price	15	view_safaripricing
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: munwan
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
11	pbkdf2_sha256$870000$w8hCExKZMEux7lgss59EyC$jsRgFaGNP+yNWWrnTEabpQcmuoeGX0yllfP40iQUt2k=	2026-05-16 18:46:25.070644+00	f	Ewenette	Ewenette	Munene	ewenettemunene@gmail.com	f	t	2026-05-09 20:10:33.815702+00
1	pbkdf2_sha256$870000$2IoCoNCQFiYwvepUOfHr5c$xnJ4L9O/m8zaaPJvfHihVhlVodtAj7WrF4yPWgJCCuo=	2026-05-16 08:54:27.670845+00	t	munwan			info@munwancarrental.com	t	t	2026-05-02 20:10:30.637124+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: munwan
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: munwan
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: core_booking; Type: TABLE DATA; Schema: public; Owner: munwan
--

COPY public.core_booking (id, reference, first_name, last_name, email, phone, nationality, hire_type, with_driver, pickup_location, hotel_address, dropoff_location, pickup_date, pickup_time, return_date, return_time, days, base_price_usd, driver_fee_usd, total_usd, total_kes, total_eur, payment_method, payment_status, payment_ref, status, ip_address, user_agent, notes, created_at, updated_at, user_id, vehicle_id, terms_accepted, baby_seat, payment_reminder_sent, payment_attempt_at, transfer_direction, transfer_zone, transfer_car_type, transfer_destination, is_night_surcharge, safari_breakdown, parent_booking_id, invoice_number, invoice_issued_at, invoice_due_date, company_name, company_kra_pin, company_address) FROM stdin;
69	DK-2026-589A65	Ewenette	Munene	ewenettemunene@gmail.com	+254794484954	Kenya	corporate	f	JKIA			2026-05-20	08:00:00	2026-05-25	08:00:00	5	290.00	0.00	290.00	37700.00	266.80	paystack	paid	DK-2026-589A65-6z7xl5	confirmed	41.90.181.130	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36		2026-05-15 13:51:47.10858+00	2026-05-15 13:51:47.10859+00	11	27	t	f	t	\N					f	\N	\N	INV-2026-9593FD	2026-05-15 13:51:47.113092+00	2026-05-19			
66	DK-2026-24DC2B	Ewenette	Munene	ewenettemunene@gmail.com	+254794484954	Kenya	normal	f	JKIA			2026-05-16	08:00:00	2026-05-19	08:00:00	3	81.00	0.00	81.00	10530.00	74.52	paystack	paid	DK-2026-24DC2B-6zhagt	confirmed	41.90.181.130	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36		2026-05-15 13:42:30.764023+00	2026-05-15 13:42:30.764038+00	11	12	t	f	t	2026-05-15 13:59:18.968462+00					f	\N	\N		\N	\N			
99	DK-2026-86F8DA	Ewenette	Munene	ewenettemunene@gmail.com	+254794484954	Kenya	corporate	f	JKIA			2026-05-18	08:00:00	2026-05-23	08:00:00	5	545.00	0.00	545.00	70850.00	501.40		invoiced		pending	41.90.181.130	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36		2026-05-15 21:37:37.418784+00	2026-05-15 21:37:37.418798+00	11	28	t	f	t	\N					f	\N	\N	INV-2026-516C56	2026-05-15 21:37:37.422581+00	2026-05-17	Munwan Car Rental	Munwan Car Rental	Munwan Car Rental
70	DK-2026-28237E	Ewenette	Munene	ewenettemunene@gmail.com	+254794484954	Kenya	normal	f	JKIA			2026-05-19	08:00:00	2026-05-20	08:00:00	1	27.00	0.00	27.00	3510.00	25.11		unpaid		pending	41.90.181.130	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36		2026-05-15 14:03:39.818087+00	2026-05-15 14:03:39.818097+00	11	12	t	f	t	2026-05-16 09:29:08.85397+00					f	\N	66		\N	\N			
\.


--
-- Data for Name: core_booking_safari_destinations; Type: TABLE DATA; Schema: public; Owner: munwan
--

COPY public.core_booking_safari_destinations (id, booking_id, safaridestination_id) FROM stdin;
\.


--
-- Data for Name: core_emailotp; Type: TABLE DATA; Schema: public; Owner: munwan
--

COPY public.core_emailotp (id, email, code, created_at, expires_at, attempts, verified_at, user_id) FROM stdin;
6	ewenettemunene@gmail.com	227798	2026-05-09 20:10:34.099812+00	2026-05-09 20:25:34.099588+00	0	2026-05-09 20:11:04.411188+00	11
\.


--
-- Data for Name: core_paymentlog; Type: TABLE DATA; Schema: public; Owner: munwan
--

COPY public.core_paymentlog (id, method, gateway_ref, amount_usd, status, raw_response, created_at, booking_id) FROM stdin;
32	paystack	DK-2026-589A65-6z7xl5	290.00	success	{"status": true, "message": "Verification successful", "data": {"id": 6149390795, "domain": "test", "status": "success", "reference": "DK-2026-589A65-6z7xl5", "receipt_number": "10101", "amount": 3770000, "message": null, "gateway_response": "Approved", "paid_at": "2026-05-15T13:52:10.000Z", "created_at": "2026-05-15T13:52:04.000Z", "channel": "mobile_money", "currency": "KES", "ip_address": "41.90.181.130", "metadata": {"booking_ref": "DK-2026-589A65", "vehicle": "Nissan X-Trail", "days": 5, "custom_fields": [{"display_name": "Booking Ref", "variable_name": "booking_ref", "value": "DK-2026-589A65"}, {"display_name": "Vehicle", "variable_name": "vehicle", "value": "Nissan X-Trail"}], "referrer": "https://munwancarrental.com/#booking"}, "log": {"start_time": 1778853125, "time_spent": 5, "attempts": 1, "errors": 0, "success": false, "mobile": true, "input": [], "history": [{"type": "action", "message": "Set payment method to: mpesa", "time": 2}, {"type": "action", "message": "Attempted to pay with mobile money", "time": 5}]}, "fees": 56550, "fees_split": null, "authorization": {"authorization_code": "AUTH_m4x0s8p61t", "bin": "071XXX", "last4": "X000", "exp_month": "12", "exp_year": "9999", "channel": "mobile_money", "card_type": "", "bank": "M-PESA", "country_code": "KE", "brand": "M-pesa", "reusable": false, "signature": null, "account_name": null, "mobile_money_number": "0710000000", "receiver_bank_account_number": null, "receiver_bank": null}, "customer": {"id": 363219271, "first_name": "Ewenette", "last_name": "Munene", "email": "ewenettemunene@gmail.com", "customer_code": "CUS_j80bbfmr12393fx", "phone": "", "metadata": null, "risk_action": "default", "international_format_phone": null}, "plan": null, "split": {}, "order_id": null, "paidAt": "2026-05-15T13:52:10.000Z", "createdAt": "2026-05-15T13:52:04.000Z", "requested_amount": 3770000, "pos_transaction_data": null, "source": null, "fees_breakdown": null, "connect": null, "transaction_date": "2026-05-15T13:52:04.000Z", "plan_object": {}, "subaccount": {}}}	2026-05-15 13:52:18.508332+00	69
33	paystack	DK-2026-24DC2B-6zhagt	81.00	success	{"status": true, "message": "Verification successful", "data": {"id": 6149407684, "domain": "test", "status": "success", "reference": "DK-2026-24DC2B-6zhagt", "receipt_number": "10101", "amount": 1053000, "message": null, "gateway_response": "Approved", "paid_at": "2026-05-15T13:59:25.000Z", "created_at": "2026-05-15T13:59:21.000Z", "channel": "mobile_money", "currency": "KES", "ip_address": "41.90.181.130", "metadata": {"booking_ref": "DK-2026-24DC2B", "vehicle": "Toyota Vitz", "days": 3, "custom_fields": [{"display_name": "Booking Ref", "variable_name": "booking_ref", "value": "DK-2026-24DC2B"}, {"display_name": "Vehicle", "variable_name": "vehicle", "value": "Toyota Vitz"}], "referrer": "https://munwancarrental.com/?resume=DK-2026-24DC2B#booking"}, "log": {"start_time": 1778853561, "time_spent": 4, "attempts": 1, "errors": 0, "success": false, "mobile": true, "input": [], "history": [{"type": "action", "message": "Set payment method to: atl_ke", "time": 3}, {"type": "action", "message": "Attempted to pay with mobile money", "time": 4}]}, "fees": 15795, "fees_split": null, "authorization": {"authorization_code": "AUTH_ft4yn3q8b5", "bin": "071XXX", "last4": "X000", "exp_month": "12", "exp_year": "9999", "channel": "mobile_money", "card_type": "", "bank": "Airtel Kenya", "country_code": "KE", "brand": "Airtel kenya", "reusable": false, "signature": null, "account_name": null, "mobile_money_number": "0710000000", "receiver_bank_account_number": null, "receiver_bank": null}, "customer": {"id": 363219271, "first_name": "Ewenette", "last_name": "Munene", "email": "ewenettemunene@gmail.com", "customer_code": "CUS_j80bbfmr12393fx", "phone": "", "metadata": null, "risk_action": "default", "international_format_phone": null}, "plan": null, "split": {}, "order_id": null, "paidAt": "2026-05-15T13:59:25.000Z", "createdAt": "2026-05-15T13:59:21.000Z", "requested_amount": 1053000, "pos_transaction_data": null, "source": null, "fees_breakdown": null, "connect": null, "transaction_date": "2026-05-15T13:59:21.000Z", "plan_object": {}, "subaccount": {}}}	2026-05-15 13:59:33.334168+00	66
\.


--
-- Data for Name: core_ratelimitentry; Type: TABLE DATA; Schema: public; Owner: munwan
--

COPY public.core_ratelimitentry (id, ip_address, action, count, window_start) FROM stdin;
7	41.90.187.252	register	3	2026-05-04 04:01:10.069196+00
8	103.226.203.76	support	1	2026-05-04 19:41:04.297269+00
9	41.90.181.174	login	1	2026-05-05 18:44:38.329155+00
11	41.90.180.21	booking	2	2026-05-09 13:14:51.303947+00
10	41.90.180.21	login	4	2026-05-09 14:29:05.997504+00
12	41.90.177.149	booking	1	2026-05-09 19:39:33.686156+00
13	41.90.177.149	register	1	2026-05-09 20:10:33.80672+00
14	41.90.176.100	login	1	2026-05-11 08:44:21.008098+00
15	41.90.185.203	login	1	2026-05-12 08:49:26.401741+00
16	41.90.176.130	login	1	2026-05-13 12:22:03.509171+00
17	41.90.181.130	login	2	2026-05-15 13:27:40.045098+00
\.


--
-- Data for Name: core_review; Type: TABLE DATA; Schema: public; Owner: munwan
--

COPY public.core_review (id, name, location, flag_emoji, rating, text, is_published, created_at, booking_id) FROM stdin;
6	James H.	United Kingdom · Tourist	🇬🇧	5	Booked the Prado from London before arriving. Car was spotless at JKIA, GPS was perfect for Maasai Mara. Paid in GBP with zero hassle.	t	2026-05-03 12:31:10.60199+00	\N
5	Wanjiru M.	Nairobi, Kenya · Business	🇰🇪	5	I'm Kenyan and usually rent from small yards. Munwan Car Rental is next level — clean cars, proper receipts and M-Pesa payment. Finally a local option I trust.	t	2026-05-03 12:30:20.912603+00	\N
4	Sofia M.	United States · NGO Worker	🇺🇸	5	Rented a Fielder for two weeks on an NGO assignment. Simple USD payment, instant confirmation, super responsive on WhatsApp. Will use again.	t	2026-05-03 12:29:41.103855+00	\N
3	Brian K.	Mombasa, Kenya · Student	🇰🇪	4	We were a group of 9 students on a field trip. The Hiace van was budget-friendly, clean and the driver knew every back road. Booking took under 5 minutes.	t	2026-05-03 12:28:49.660346+00	\N
2	Lukas & Family	Germany · Family Tourist	🇩🇪	5	Amazing service. The Prado was immaculate for our family safari. Delivered to our hotel. Kids loved the roof hatch. Worth every dollar.	t	2026-05-03 12:26:43.869526+00	\N
1	Amara O.	Nairobi · Corporate Client	🇰🇪	5	Used the Alphard for an executive airport transfer. Client was very impressed. We now use Munwan Car Rental for all our company car hire needs.	t	2026-05-03 12:25:45.407136+00	\N
\.


--
-- Data for Name: core_safaridestination; Type: TABLE DATA; Schema: public; Owner: munwan
--

COPY public.core_safaridestination (id, name, short_name, slug, description, distance_km, recommended_days, is_active, "order") FROM stdin;
1	Maasai Mara National Reserve	Maasai Mara	maasai-mara	World-famous game reserve — Big Five, Great Migration July-October.	270	3	t	1
2	Amboseli National Park	Amboseli	amboseli	Iconic elephant herds with Kilimanjaro views to the south.	240	2	t	2
3	Lake Nakuru National Park	Lake Nakuru	lake-nakuru	Flamingos, rhinos, leopards. Easy 1-2 day trip from Nairobi.	160	1	t	3
4	Lake Naivasha & Hells Gate	Lake Naivasha	lake-naivasha	Hippos, boat trips, walking safari at Hell's Gate.	90	1	t	4
5	Ol Pejeta Conservancy	Ol Pejeta	ol-pejeta	The last two northern white rhinos. Big Five, chimpanzee sanctuary.	220	2	t	5
6	Tsavo East National Park	Tsavo East	tsavo-east	Huge red-dust park. Elephants, lions, Yatta Plateau.	320	2	t	6
7	Tsavo West National Park	Tsavo West	tsavo-west	Volcanic landscapes, Mzima Springs, rhino sanctuary.	330	2	t	7
8	Samburu National Reserve	Samburu	samburu	Northern reserve — special-five (Grevy zebra, reticulated giraffe, etc.).	350	3	t	8
9	Nairobi National Park	Nairobi NP	nairobi-np	Big game inside the city. 5-hour half-day trip.	10	1	t	9
10	Hell's Gate National Park	Hell's Gate	hells-gate	Cycle and walk among zebra/giraffe. Day trip from Nairobi.	90	1	t	10
\.


--
-- Data for Name: core_safaripricing; Type: TABLE DATA; Schema: public; Owner: munwan
--

COPY public.core_safaripricing (id, price_usd, notes, destination_id, vehicle_id) FROM stdin;
1	300.00		1	9
2	195.00		1	10
3	175.00		1	17
4	275.00		2	9
5	185.00		2	10
6	165.00		2	17
7	265.00		3	9
8	165.00		3	10
9	150.00		3	17
10	250.00		4	9
11	160.00		4	10
12	145.00		4	17
13	280.00		5	9
14	175.00		5	10
15	160.00		5	17
16	325.00		6	9
17	215.00		6	10
18	195.00		6	17
19	325.00		7	9
20	215.00		7	10
21	195.00		7	17
22	325.00		8	9
23	210.00		8	10
24	195.00		8	17
25	225.00		9	9
26	135.00		9	10
27	125.00		9	17
28	265.00		10	9
29	160.00		10	10
30	145.00		10	17
\.


--
-- Data for Name: core_supportticket; Type: TABLE DATA; Schema: public; Owner: munwan
--

COPY public.core_supportticket (id, name, email, phone, subject, message, booking_ref, status, ip_address, created_at) FROM stdin;
1	Ewenette Munene	ewenettemunene@gmail.com	+254794484954	A	B		open	41.90.185.91	2026-05-02 22:50:14.249206+00
2	Sofia	free.derek73@gmail.com		1st Page	Hi http://munwancarrental.com,\r\n\r\nGreetings for the day!\r\n\r\nI am (Online Marketing Manager), contacting you after checking your website.\r\n\r\nI was looking at your website and realized that despite having a great design; it was not ranking high on any of the search engines (Google, AOL and Bing).\r\n\r\nI am affiliated with a SEO company that has helped over 150+ businesses achieve 1st Page listing on Google search result page for highly competitive keywords.\r\n\r\nWe have some Low cost and special offers!!\r\n\r\nLet me know if you are interested, I will send you our SEO Packages and price list.\r\n\r\nWarm Regards,\r\nSofia		open	103.226.203.76	2026-05-04 19:41:04.302397+00
\.


--
-- Data for Name: core_vehicle; Type: TABLE DATA; Schema: public; Owner: munwan
--

COPY public.core_vehicle (id, name, slug, category, badge, description, seats, fuel, transmission, has_ac, has_gps, price_usd, price_kes, price_eur, driver_fee_usd, image, is_available, "order", transfer_car_type) FROM stdin;
23	Nissan Serena	nissan-serena	mid	mid	8-seat MPV · Family & small groups	8	Petrol	Automatic	t	t	58.00	7500.00	49.00	15.00	cars/serena.jpg	t	5	midsize
10	Toyota Hiace	toyota-hiace	safari	saf	14-seat minibus · Tours & group transfers	14	Diesel	Automatic	t	t	116.00	15000.00	99.00	25.00	cars/hiace.jfif	t	7	van
11	Toyota Esquire	toyota-esquire	van	mid	Premium MPV · Business & family	7	Petrol	Automatic	t	t	58.00	7500.00	49.00	15.00	cars/esquire.jpg	t	10	midsize
19	Subaru Forester	subaru-forester	suv	mid	All-Wheel Drive · Rugged & reliable	5	Petrol	Automatic	t	t	62.00	8000.00	53.00	15.00	cars/forester.jpg	t	13	midsize
22	Range Rover E vogue	range-rover-e-vogue	suv	lux	Iconic luxury SUV · Statement of arrival	5	Petrol	Automatic	t	t	233.00	30000.00	197.00	15.00	cars/range.jfif	t	14	
21	Nissan Patrol	nissan-patrol	luxury	exec	Premium 4×4 SUV · Power & prestige	7	Petrol	Automatic	t	t	124.00	16000.00	105.00	15.00	cars/patrol.jfif	t	15	luxury
14	Mercedes Benz C200	mercedes-benz-c200	luxury	lux	Compact luxury · Refined city driving	5	Petrol	Automatic	t	t	132.00	17000.00	112.00	15.00	cars/c200.jfif	t	16	luxury
16	Mazda CX5	mazda-cx5	mid	mid	Crossover SUV · Style & performance	5	Petrol	Automatic	t	t	62.00	8000.00	52.00	15.00	cars/cx5.jpg	t	18	midsize
17	Toyota Hilux	toyota-hilux	safari	saf	Safari-ready double-cab · Built for off-road	5	Diesel	Automatic	t	t	78.00	10000.00	66.00	15.00	cars/hilux.jfif	t	19	
26	Toyota Harrier	toyota-harrier	suv	lux	Luxury SUV · Comfort cruising	5	Petrol	Automatic	t	t	53.00	8000.00	49.00	15.00	cars/harrier.jpg	t	4	midsize
9	Land Cruiser HardRoof	land-cruiser-hardroof	safari	saf	Iconic safari 4×4 · Pop-up roof for game viewing	7	Diesel	Manual	t	t	217.00	28000.00	185.00	25.00	cars/land_cruiser.jfif	t	6	
24	Toyota Coaster Bus	toyota-coaster-bus	van	van	26-seat coach · Large groups & events	26	Diesel	Automatic	t	t	155.00	20000.00	132.00	25.00	cars/coaster.jpg	t	8	van
20	Toyota Alphard	toyota-alphard	luxury	lux	Luxury MPV · VIP & executive transfers	7	Petrol	Automatic	t	t	93.00	12000.00	79.00	15.00	cars/alphard.jpg	t	9	luxury
15	Mercedes Benz E Class	mercedes-benz-e-class	luxury	lux	German luxury · Executive class	5	Petrol	Automatic	t	t	155.00	20000.00	132.00	15.00	cars/eClass.jfif	t	17	luxury
27	Nissan X-Trail	nissan-x-trail	mid	pop	Most popular crossover · Family & city travel	5	Petrol	Automatic	t	t	58.00	7500.00	49.00	15.00	cars/x-trail.jpg	t	2	midsize
25	Lexus LX570	lexus-lx570	suv	exec	Ultra-luxury SUV · Top-tier executive	7	Petrol	Automatic	t	t	310.00	40000.00	263.00	15.00	cars/lx570.jfif	t	3	luxury
28	Toyota Prado	toyota-prado	suv	lux	Premium 4×4 · Business & comfort travel	7	Diesel	Automatic	t	t	109.00	14000.00	92.00	15.00	cars/prado.jpg	t	1	luxury
18	Toyota Rav4	toyota-rav4	mid	mid	Compact SUV · Cities & short safaris	5	Petrol	Automatic	t	t	62.00	8000.00	53.00	15.00	cars/rav4.jpg	t	11	midsize
2	Nissan Note	nissan-note	economy	eco	Compact hatchback · Budget city runabout	5	Petrol	Automatic	t	t	27.00	3500.00	23.00	15.00	cars/note_CXfhETU.jpg	t	28	economy
13	Toyota Vanguard	toyota-vanguard	suv	mid	Reliable SUV · Family travel	5	Petrol	Automatic	t	t	62.00	8000.00	53.00	15.00	cars/vanguard.jpg	t	12	midsize
4	Toyota Mark X	toyota-mark-x	economy	eco	Sporty saloon · Comfort & style	5	Petrol	Automatic	t	t	40.00	5000.00	33.00	15.00	cars/markx.jfif	t	21	economy
5	Toyota Fielder	toyota-fielder	economy	eco	Estate saloon · City & upcountry trips	5	Petrol	Automatic	t	t	40.00	5000.00	33.00	15.00	cars/fielder.jpg	t	23	economy
8	Toyota Corolla	toyota-corolla	economy	eco	Classic saloon · Easy city driving	5	Petrol	Automatic	t	t	40.00	5000.00	33.00	15.00	cars/corolla.jfif	t	24	economy
12	Toyota Vitz	toyota-vitz	economy	eco	Compact hatchback · Easy parking, fuel-efficient	5	Petrol	Automatic	t	t	27.00	3500.00	23.00	15.00	cars/vitz.jfif	t	27	economy
3	Mazda Demio	mazda-demio	economy	eco	Subcompact · Fuel-efficient city car	5	Petrol	Automatic	t	t	27.00	3500.00	23.00	15.00	cars/demio.jpg	t	26	economy
1	Toyota Axio	toyota-axio	economy	eco	Reliable economy saloon · Long-distance friendly	5	Petrol	Automatic	t	t	35.00	4500.00	30.00	15.00	cars/1000004289_U2XjCX6.jpg	t	25	economy
7	Mazda Axella	mazda-axella	mid	mid	Stylish saloon · Daily driving	5	Petrol	Automatic	t	t	39.00	5000.00	33.00	15.00	cars/axella.jfif	t	22	economy
6	Toyota Crown	toyota-crown	mid	exec	Executive saloon · Comfortable business travel	5	Petrol	Automatic	t	t	55.00	7000.00	47.00	15.00	cars/crown.jpg	t	20	
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: munwan
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2026-05-02 20:44:58.662941+00	1	Toyota Axio	1	[{"added": {}}]	7	1
2	2026-05-02 22:37:35.935583+00	1	Toyota Axio	2	[{"changed": {"fields": ["Image"]}}]	7	1
3	2026-05-02 22:37:43.966309+00	1	Toyota Axio	2	[{"changed": {"fields": ["Image"]}}]	7	1
4	2026-05-03 10:48:02.283112+00	2	Nissan Note	1	[{"added": {}}]	7	1
5	2026-05-03 10:48:30.711041+00	2	Nissan Note	2	[{"changed": {"fields": ["Image"]}}]	7	1
6	2026-05-03 10:48:45.198743+00	2	Nissan Note	2	[{"changed": {"fields": ["Image"]}}]	7	1
7	2026-05-03 10:49:54.968827+00	3	Mazda Demio	1	[{"added": {}}]	7	1
8	2026-05-03 10:51:18.440187+00	4	Toyota Mark X	1	[{"added": {}}]	7	1
9	2026-05-03 10:52:52.232495+00	5	Toyota Fielder	1	[{"added": {}}]	7	1
10	2026-05-03 10:55:39.982919+00	6	Toyota Crown	1	[{"added": {}}]	7	1
11	2026-05-03 10:56:54.147825+00	7	Mazda Axella	1	[{"added": {}}]	7	1
12	2026-05-03 11:18:36.391391+00	8	Toyota Corolla	1	[{"added": {}}]	7	1
13	2026-05-03 11:23:30.394154+00	9	Land Cruiser HardRoof	1	[{"added": {}}]	7	1
14	2026-05-03 11:25:57.690582+00	10	Toyota Hiace	1	[{"added": {}}]	7	1
15	2026-05-03 11:29:01.098235+00	11	Toyota Esquire	1	[{"added": {}}]	7	1
16	2026-05-03 11:32:29.325565+00	12	Toyota Vitz	1	[{"added": {}}]	7	1
17	2026-05-03 11:35:24.732347+00	13	Toyota Vanguard	1	[{"added": {}}]	7	1
18	2026-05-03 11:37:20.617729+00	14	Mercedes Benz C200	1	[{"added": {}}]	7	1
19	2026-05-03 11:38:49.172081+00	15	Mercedes Benz E Class	1	[{"added": {}}]	7	1
20	2026-05-03 11:40:41.640728+00	16	Mazda CX5	1	[{"added": {}}]	7	1
21	2026-05-03 11:42:48.133522+00	17	Toyota Hilux	1	[{"added": {}}]	7	1
22	2026-05-03 11:44:32.248482+00	18	Toyota Rav4	1	[{"added": {}}]	7	1
23	2026-05-03 11:47:19.119361+00	19	Subaru Forester	1	[{"added": {}}]	7	1
24	2026-05-03 11:48:34.212653+00	20	Toyota Alphard	1	[{"added": {}}]	7	1
25	2026-05-03 11:57:09.731116+00	21	Nissan Patrol	1	[{"added": {}}]	7	1
26	2026-05-03 11:59:41.963102+00	22	Range Rover E vogue	1	[{"added": {}}]	7	1
27	2026-05-03 12:02:19.504988+00	23	Nissan Serena	1	[{"added": {}}]	7	1
28	2026-05-03 12:08:05.099844+00	24	Toyota Coaster Bus	1	[{"added": {}}]	7	1
29	2026-05-03 12:10:24.12258+00	25	Lexus LX570	1	[{"added": {}}]	7	1
30	2026-05-03 12:12:25.772109+00	26	Toyota Harrier	1	[{"added": {}}]	7	1
31	2026-05-03 12:13:26.991082+00	27	Nissan X-Trail	1	[{"added": {}}]	7	1
32	2026-05-03 12:14:29.221886+00	28	Toyota Prado	1	[{"added": {}}]	7	1
33	2026-05-03 12:16:04.957828+00	25	Lexus LX570	2	[{"changed": {"fields": ["Seats"]}}]	7	1
34	2026-05-03 12:16:53.677101+00	9	Land Cruiser HardRoof	2	[{"changed": {"fields": ["Seats"]}}]	7	1
35	2026-05-03 12:17:53.492016+00	23	Nissan Serena	2	[{"changed": {"fields": ["Seats"]}}]	7	1
36	2026-05-03 12:18:20.0897+00	23	Nissan Serena	2	[{"changed": {"fields": ["Seats"]}}]	7	1
37	2026-05-03 12:25:45.411683+00	1	Amara O. – 5★	1	[{"added": {}}]	10	1
38	2026-05-03 12:26:43.871041+00	2	Lukas & Family – 5★	1	[{"added": {}}]	10	1
39	2026-05-03 12:27:40.950896+00	2	Lukas & Family – 5★	2	[{"changed": {"fields": ["Flag emoji"]}}]	10	1
40	2026-05-03 12:28:49.661956+00	3	Brian K. – 4★	1	[{"added": {}}]	10	1
41	2026-05-03 12:29:41.105659+00	4	Sofia M. – 5★	1	[{"added": {}}]	10	1
42	2026-05-03 12:30:20.914703+00	5	Wanjiru M. – 5★	1	[{"added": {}}]	10	1
43	2026-05-03 12:31:10.603516+00	6	James H. – 5★	1	[{"added": {}}]	10	1
44	2026-05-03 13:19:52.710977+00	25	Lexus LX570	2	[{"changed": {"fields": ["Price usd", "Price eur"]}}]	7	1
45	2026-05-03 13:36:01.782971+00	3	Mazda Demio	2	[]	7	1
46	2026-05-03 13:36:14.406923+00	2	Nissan Note	2	[]	7	1
47	2026-05-03 13:36:36.031774+00	21	Nissan Patrol	2	[]	7	1
48	2026-05-03 14:20:49.108253+00	25	Lexus LX570	2	[{"changed": {"fields": ["Order"]}}]	7	1
49	2026-05-03 14:21:33.205494+00	25	Lexus LX570	2	[{"changed": {"fields": ["Order"]}}]	7	1
50	2026-05-03 18:55:36.92221+00	25	Lexus LX570	2	[{"changed": {"fields": ["Price usd", "Price eur", "Driver fee usd"]}}]	7	1
51	2026-05-03 18:56:12.613912+00	4	Toyota Mark X	2	[{"changed": {"fields": ["Price eur", "Driver fee usd"]}}]	7	1
52	2026-05-03 18:57:13.077544+00	2	Nissan Note	2	[{"changed": {"fields": ["Order"]}}]	7	1
53	2026-05-03 18:57:13.079268+00	1	Toyota Axio	2	[{"changed": {"fields": ["Order"]}}]	7	1
54	2026-05-03 18:57:13.080374+00	8	Toyota Corolla	2	[{"changed": {"fields": ["Order"]}}]	7	1
55	2026-05-03 18:57:13.081459+00	12	Toyota Vitz	2	[{"changed": {"fields": ["Order"]}}]	7	1
56	2026-05-03 18:59:16.15655+00	7	Mazda Axella	2	[{"changed": {"fields": ["Order"]}}]	7	1
57	2026-05-03 18:59:16.158492+00	3	Mazda Demio	2	[{"changed": {"fields": ["Order"]}}]	7	1
58	2026-05-03 18:59:16.159842+00	6	Toyota Crown	2	[{"changed": {"fields": ["Order"]}}]	7	1
59	2026-05-03 18:59:16.160988+00	5	Toyota Fielder	2	[{"changed": {"fields": ["Order"]}}]	7	1
60	2026-05-03 18:59:16.162123+00	4	Toyota Mark X	2	[{"changed": {"fields": ["Order"]}}]	7	1
61	2026-05-03 18:59:16.163145+00	12	Toyota Vitz	2	[{"changed": {"fields": ["Order"]}}]	7	1
62	2026-05-03 19:05:27.326849+00	9	Land Cruiser HardRoof	2	[{"changed": {"fields": ["Order"]}}]	7	1
63	2026-05-03 19:05:27.328907+00	25	Lexus LX570	2	[{"changed": {"fields": ["Order"]}}]	7	1
64	2026-05-03 19:05:27.33017+00	16	Mazda CX5	2	[{"changed": {"fields": ["Order"]}}]	7	1
65	2026-05-03 19:05:27.331492+00	14	Mercedes Benz C200	2	[{"changed": {"fields": ["Order"]}}]	7	1
66	2026-05-03 19:05:27.332548+00	15	Mercedes Benz E Class	2	[{"changed": {"fields": ["Order"]}}]	7	1
67	2026-05-03 19:05:27.333632+00	21	Nissan Patrol	2	[{"changed": {"fields": ["Order"]}}]	7	1
68	2026-05-03 19:05:27.334833+00	23	Nissan Serena	2	[{"changed": {"fields": ["Order"]}}]	7	1
69	2026-05-03 19:05:27.335936+00	27	Nissan X-Trail	2	[{"changed": {"fields": ["Order"]}}]	7	1
70	2026-05-03 19:05:27.336941+00	22	Range Rover E vogue	2	[{"changed": {"fields": ["Order"]}}]	7	1
71	2026-05-03 19:05:27.338027+00	19	Subaru Forester	2	[{"changed": {"fields": ["Order"]}}]	7	1
72	2026-05-03 19:05:27.339037+00	20	Toyota Alphard	2	[{"changed": {"fields": ["Order"]}}]	7	1
73	2026-05-03 19:05:27.340072+00	24	Toyota Coaster Bus	2	[{"changed": {"fields": ["Order"]}}]	7	1
74	2026-05-03 19:05:27.341136+00	11	Toyota Esquire	2	[{"changed": {"fields": ["Order"]}}]	7	1
75	2026-05-03 19:05:27.342172+00	26	Toyota Harrier	2	[{"changed": {"fields": ["Order"]}}]	7	1
76	2026-05-03 19:05:27.343284+00	10	Toyota Hiace	2	[{"changed": {"fields": ["Order"]}}]	7	1
77	2026-05-03 19:05:27.344395+00	17	Toyota Hilux	2	[{"changed": {"fields": ["Order"]}}]	7	1
78	2026-05-03 19:05:27.345699+00	28	Toyota Prado	2	[{"changed": {"fields": ["Order"]}}]	7	1
79	2026-05-03 19:05:27.34685+00	18	Toyota Rav4	2	[{"changed": {"fields": ["Order"]}}]	7	1
80	2026-05-03 19:05:27.348016+00	13	Toyota Vanguard	2	[{"changed": {"fields": ["Order"]}}]	7	1
81	2026-05-03 19:05:27.349201+00	1	Toyota Axio	2	[{"changed": {"fields": ["Order"]}}]	7	1
82	2026-05-03 19:05:27.35039+00	12	Toyota Vitz	2	[{"changed": {"fields": ["Order"]}}]	7	1
83	2026-05-03 19:05:27.351439+00	8	Toyota Corolla	2	[{"changed": {"fields": ["Order"]}}]	7	1
84	2026-05-03 19:05:27.352479+00	2	Nissan Note	2	[{"changed": {"fields": ["Order"]}}]	7	1
85	2026-05-03 19:05:27.353513+00	4	Toyota Mark X	2	[{"changed": {"fields": ["Order"]}}]	7	1
86	2026-05-03 19:05:27.354542+00	5	Toyota Fielder	2	[{"changed": {"fields": ["Order"]}}]	7	1
87	2026-05-03 19:05:27.355533+00	6	Toyota Crown	2	[{"changed": {"fields": ["Order"]}}]	7	1
88	2026-05-03 19:05:27.356606+00	3	Mazda Demio	2	[{"changed": {"fields": ["Order"]}}]	7	1
89	2026-05-03 19:05:27.357621+00	7	Mazda Axella	2	[{"changed": {"fields": ["Order"]}}]	7	1
90	2026-05-03 19:05:55.134399+00	6	Toyota Crown	2	[{"changed": {"fields": ["Order"]}}]	7	1
91	2026-05-03 19:05:55.136441+00	5	Toyota Fielder	2	[{"changed": {"fields": ["Order"]}}]	7	1
92	2026-05-03 19:05:55.137614+00	8	Toyota Corolla	2	[{"changed": {"fields": ["Order"]}}]	7	1
93	2026-05-03 19:05:55.138728+00	3	Mazda Demio	2	[{"changed": {"fields": ["Order"]}}]	7	1
94	2026-05-03 19:05:55.139878+00	1	Toyota Axio	2	[{"changed": {"fields": ["Order"]}}]	7	1
95	2026-05-03 19:05:55.141+00	12	Toyota Vitz	2	[{"changed": {"fields": ["Order"]}}]	7	1
96	2026-05-03 19:05:55.142059+00	2	Nissan Note	2	[{"changed": {"fields": ["Order"]}}]	7	1
97	2026-05-03 19:13:28.895151+00	28	Toyota Prado	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
98	2026-05-03 19:13:38.670217+00	27	Nissan X-Trail	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
99	2026-05-03 19:13:52.506807+00	25	Lexus LX570	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
100	2026-05-03 19:14:04.767401+00	26	Toyota Harrier	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
101	2026-05-03 19:14:16.300336+00	23	Nissan Serena	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
102	2026-05-03 19:14:41.96411+00	24	Toyota Coaster Bus	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
103	2026-05-03 19:17:22.763005+00	28	Toyota Prado	2	[{"changed": {"fields": ["Price usd", "Price kes", "Price eur"]}}]	7	1
104	2026-05-03 19:18:30.968186+00	26	Toyota Harrier	2	[{"changed": {"fields": ["Price usd", "Price eur"]}}]	7	1
105	2026-05-03 19:19:51.728903+00	11	Toyota Esquire	2	[{"changed": {"fields": ["Price kes", "Price eur"]}}]	7	1
106	2026-05-03 19:20:43.504669+00	26	Toyota Harrier	2	[{"changed": {"fields": ["Price kes"]}}]	7	1
107	2026-05-03 20:50:25.755588+00	17	Toyota Hilux	2	[{"changed": {"fields": ["Category", "Badge"]}}]	7	1
108	2026-05-03 20:50:58.79624+00	17	Toyota Hilux	2	[{"changed": {"fields": ["Badge"]}}]	7	1
109	2026-05-03 20:51:34.418009+00	17	Toyota Hilux	2	[{"changed": {"fields": ["Category"]}}]	7	1
110	2026-05-03 20:54:34.177203+00	5	Munene	3		4	1
111	2026-05-03 21:06:52.628544+00	6	Munene	3		4	1
112	2026-05-03 21:37:43.036956+00	2	Nissan Note	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
113	2026-05-03 21:37:54.675132+00	28	Toyota Prado	2	[]	7	1
114	2026-05-03 21:38:00.123176+00	27	Nissan X-Trail	2	[]	7	1
115	2026-05-03 21:38:07.097732+00	25	Lexus LX570	2	[]	7	1
116	2026-05-03 21:38:12.502626+00	26	Toyota Harrier	2	[]	7	1
117	2026-05-03 21:38:17.976383+00	23	Nissan Serena	2	[]	7	1
118	2026-05-03 21:38:29.658673+00	9	Land Cruiser HardRoof	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
119	2026-05-03 21:38:42.026306+00	10	Toyota Hiace	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
120	2026-05-03 21:38:52.719623+00	24	Toyota Coaster Bus	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
121	2026-05-03 21:39:17.086578+00	20	Toyota Alphard	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
122	2026-05-03 21:39:27.570808+00	11	Toyota Esquire	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
123	2026-05-03 21:39:40.163983+00	18	Toyota Rav4	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
124	2026-05-03 21:39:50.003114+00	13	Toyota Vanguard	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
125	2026-05-03 21:40:06.922406+00	19	Subaru Forester	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
126	2026-05-03 21:40:18.442582+00	22	Range Rover E vogue	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
127	2026-05-03 21:40:31.579575+00	21	Nissan Patrol	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
128	2026-05-03 21:40:40.674782+00	14	Mercedes Benz C200	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
129	2026-05-03 21:40:55.164739+00	15	Mercedes Benz E Class	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
130	2026-05-03 21:41:06.934367+00	16	Mazda CX5	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
131	2026-05-03 21:41:19.870946+00	17	Toyota Hilux	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
132	2026-05-03 21:41:31.586609+00	7	Mazda Axella	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
133	2026-05-03 21:41:41.343997+00	4	Toyota Mark X	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
134	2026-05-03 21:41:52.402568+00	6	Toyota Crown	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
135	2026-05-03 21:42:03.694908+00	5	Toyota Fielder	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
136	2026-05-03 21:42:15.372578+00	8	Toyota Corolla	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
137	2026-05-03 21:42:26.0697+00	3	Mazda Demio	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
138	2026-05-03 21:42:36.307155+00	1	Toyota Axio	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
139	2026-05-03 21:42:46.109976+00	12	Toyota Vitz	2	[{"changed": {"fields": ["Driver fee usd"]}}]	7	1
140	2026-05-03 21:42:53.798758+00	2	Nissan Note	2	[]	7	1
141	2026-05-03 21:45:39.6454+00	25	Lexus LX570	2	[{"changed": {"fields": ["Badge"]}}]	7	1
142	2026-05-03 21:46:12.072379+00	10	Toyota Hiace	2	[{"changed": {"fields": ["Badge"]}}]	7	1
143	2026-05-03 21:46:49.817157+00	11	Toyota Esquire	2	[{"changed": {"fields": ["Badge"]}}]	7	1
144	2026-05-03 21:47:10.29194+00	21	Nissan Patrol	2	[{"changed": {"fields": ["Badge"]}}]	7	1
145	2026-05-03 21:48:12.949853+00	10	Toyota Hiace	2	[{"changed": {"fields": ["Category"]}}]	7	1
146	2026-05-09 08:00:40.223839+00	28	Toyota Prado	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
147	2026-05-09 08:00:40.225816+00	27	Nissan X-Trail	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
148	2026-05-09 08:00:40.226946+00	25	Lexus LX570	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
149	2026-05-09 08:00:40.228197+00	26	Toyota Harrier	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
150	2026-05-09 08:00:40.229453+00	23	Nissan Serena	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
151	2026-05-09 08:00:40.230618+00	10	Toyota Hiace	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
152	2026-05-09 08:00:40.23181+00	24	Toyota Coaster Bus	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
153	2026-05-09 08:00:40.233182+00	20	Toyota Alphard	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
154	2026-05-09 08:00:40.234428+00	11	Toyota Esquire	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
155	2026-05-09 08:00:40.235636+00	18	Toyota Rav4	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
156	2026-05-09 08:00:40.236787+00	13	Toyota Vanguard	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
157	2026-05-09 08:00:40.237849+00	19	Subaru Forester	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
158	2026-05-09 08:00:40.238886+00	21	Nissan Patrol	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
159	2026-05-09 08:00:40.23985+00	14	Mercedes Benz C200	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
160	2026-05-09 08:00:40.240907+00	15	Mercedes Benz E Class	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
161	2026-05-09 08:00:40.241906+00	16	Mazda CX5	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
162	2026-05-09 08:00:40.243167+00	7	Mazda Axella	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
163	2026-05-09 08:00:40.244356+00	4	Toyota Mark X	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
164	2026-05-09 08:00:40.245615+00	5	Toyota Fielder	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
165	2026-05-09 08:00:40.246744+00	8	Toyota Corolla	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
166	2026-05-09 08:00:40.247875+00	3	Mazda Demio	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
167	2026-05-09 08:00:40.24921+00	1	Toyota Axio	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
168	2026-05-09 08:00:40.250379+00	12	Toyota Vitz	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
169	2026-05-09 08:00:40.251542+00	2	Nissan Note	2	[{"changed": {"fields": ["Transfer car type"]}}]	7	1
170	2026-05-09 14:22:44.404279+00	15	DK-2026-88F79B – Ewenette Munene	3		8	1
171	2026-05-09 14:22:44.404325+00	14	DK-2026-C41DE3 – Ewenette Munene	3		8	1
172	2026-05-09 14:22:44.404348+00	6	DK-2026-E67B64 – Ewenette Munene	3		8	1
173	2026-05-09 14:22:44.404366+00	5	DK-2026-296935 – Ewenette Munene	3		8	1
174	2026-05-09 14:22:44.404383+00	4	DK-2026-B02F48 – Ewenette Munene	3		8	1
175	2026-05-09 14:22:44.404399+00	3	DK-2026-8825B6 – Ewenette Munene	3		8	1
176	2026-05-09 14:22:44.404414+00	2	DK-2026-28FBC4 – Ewenette Munene	3		8	1
177	2026-05-09 14:22:44.404429+00	1	DK-2026-B1E6C9 – Ewenette Munene	3		8	1
178	2026-05-09 14:37:59.77236+00	18	DK-2026-BC7621 – Ewenette Munene	3		8	1
179	2026-05-09 19:30:09.737316+00	19	DK-2026-30C5CF – Ewenette Munene	3		8	1
180	2026-05-09 19:30:09.737362+00	17	DK-2026-7BE5F3 – Ewenette Munene	3		8	1
181	2026-05-09 19:30:09.737386+00	16	DK-2026-9FE428 – Ewenette Munene	3		8	1
182	2026-05-09 19:30:22.604125+00	4	ewenettemunene@gmail.com	3		4	1
183	2026-05-09 20:09:33.406663+00	10	ewenettemunene@gmail.com	3		4	1
184	2026-05-09 20:09:46.284604+00	23	DK-2026-42D574 – Ewenette Munene	3		8	1
185	2026-05-09 20:09:46.284653+00	22	DK-2026-69B974 – Ewenette Munene	3		8	1
186	2026-05-09 20:09:46.284677+00	21	DK-2026-E4ADF3 – Ewenette Munene	3		8	1
187	2026-05-09 20:09:46.284696+00	20	DK-2026-E18515 – Ewenette Munene	3		8	1
188	2026-05-09 20:56:10.342387+00	26	DK-2026-57043A – Ewenette Munene	3		8	1
189	2026-05-09 20:56:10.342439+00	25	DK-2026-E00EC7 – Ewenette Munene	3		8	1
190	2026-05-09 20:56:10.342466+00	24	DK-2026-AFD364 – Ewenette Munene	3		8	1
191	2026-05-09 21:16:49.911995+00	29	DK-2026-EE60F5 – Ewenette Munene	2	[{"changed": {"fields": ["Payment status", "Payment method"]}}]	8	1
192	2026-05-09 21:17:36.616672+00	29	DK-2026-EE60F5 – Ewenette Munene	2	[{"changed": {"fields": ["Status"]}}]	8	1
193	2026-05-10 14:13:43.432588+00	27	Nissan X-Trail	2	[{"changed": {"fields": ["Price usd", "Price kes", "Price eur"]}}]	7	1
194	2026-05-10 14:15:36.095853+00	28	Toyota Prado	2	[{"changed": {"fields": ["Price usd", "Price kes", "Price eur"]}}]	7	1
195	2026-05-10 14:17:57.688113+00	25	Lexus LX570	2	[{"changed": {"fields": ["Price usd", "Price kes", "Price eur"]}}]	7	1
196	2026-05-10 14:19:53.570764+00	26	Toyota Harrier	2	[{"changed": {"fields": ["Price usd", "Price kes"]}}]	7	1
197	2026-05-10 14:22:36.726029+00	23	Nissan Serena	2	[{"changed": {"fields": ["Price usd", "Price kes", "Price eur"]}}]	7	1
198	2026-05-10 14:25:06.4258+00	10	Toyota Hiace	2	[{"changed": {"fields": ["Price usd", "Price kes", "Price eur"]}}]	7	1
199	2026-05-10 14:26:37.428149+00	11	Toyota Esquire	2	[{"changed": {"fields": ["Price usd", "Price kes", "Price eur"]}}]	7	1
200	2026-05-10 14:28:43.70335+00	18	Toyota Rav4	2	[{"changed": {"fields": ["Price usd", "Price kes", "Price eur"]}}]	7	1
201	2026-05-10 14:29:48.779221+00	19	Subaru Forester	2	[{"changed": {"fields": ["Price usd", "Price kes", "Price eur"]}}]	7	1
202	2026-05-10 14:31:45.110925+00	22	Range Rover E vogue	2	[{"changed": {"fields": ["Price usd", "Price kes", "Price eur"]}}]	7	1
203	2026-05-10 14:33:39.503011+00	21	Nissan Patrol	2	[{"changed": {"fields": ["Price usd", "Price kes", "Price eur"]}}]	7	1
204	2026-05-10 14:35:13.220188+00	14	Mercedes Benz C200	2	[{"changed": {"fields": ["Price usd", "Price kes", "Price eur"]}}]	7	1
205	2026-05-10 14:35:59.499682+00	16	Mazda CX5	2	[{"changed": {"fields": ["Price usd", "Price kes", "Price eur"]}}]	7	1
206	2026-05-10 14:37:45.195948+00	17	Toyota Hilux	2	[{"changed": {"fields": ["Price usd", "Price kes", "Price eur"]}}]	7	1
207	2026-05-10 14:38:59.516082+00	7	Mazda Axella	2	[{"changed": {"fields": ["Price usd", "Price kes", "Price eur"]}}]	7	1
208	2026-05-10 14:41:24.988169+00	1	Toyota Axio	2	[{"changed": {"fields": ["Price usd", "Price kes", "Price eur"]}}]	7	1
209	2026-05-10 14:42:00.889787+00	3	Mazda Demio	2	[{"changed": {"fields": ["Price usd", "Price kes", "Price eur"]}}]	7	1
210	2026-05-10 14:42:21.29985+00	12	Toyota Vitz	2	[{"changed": {"fields": ["Price usd", "Price kes", "Price eur"]}}]	7	1
211	2026-05-10 14:42:37.832047+00	2	Nissan Note	2	[{"changed": {"fields": ["Price usd", "Price kes", "Price eur"]}}]	7	1
212	2026-05-10 14:46:59.941392+00	26	Toyota Harrier	2	[{"changed": {"fields": ["Price eur"]}}]	7	1
213	2026-05-10 14:47:26.603418+00	12	Toyota Vitz	2	[{"changed": {"fields": ["Price kes"]}}]	7	1
214	2026-05-11 09:13:19.513528+00	3	Mazda Demio	2	[{"changed": {"fields": ["Order"]}}]	7	1
215	2026-05-11 09:13:19.515292+00	1	Toyota Axio	2	[{"changed": {"fields": ["Order"]}}]	7	1
216	2026-05-11 09:13:54.111129+00	7	Mazda Axella	2	[{"changed": {"fields": ["Order"]}}]	7	1
217	2026-05-11 09:13:54.112703+00	6	Toyota Crown	2	[{"changed": {"fields": ["Order"]}}]	7	1
218	2026-05-12 09:16:03.590106+00	40	DK-2026-D71AC5 – Ewenette Munene	3		8	1
219	2026-05-12 14:02:52.78322+00	42	DK-2026-C99CA0 – Ewenette Munene	3		8	1
220	2026-05-12 14:02:52.783302+00	41	DK-2026-DE4787 – Ewenette Munene	3		8	1
221	2026-05-12 14:07:01.267751+00	44	DK-2026-3698D4 – Ewenette Munene	3		8	1
222	2026-05-12 14:07:01.267814+00	43	DK-2026-D1D781 – Ewenette Munene	3		8	1
223	2026-05-12 14:07:01.267853+00	37	DK-2026-FBA1B7 – Ewenette Munene	3		8	1
224	2026-05-12 14:07:01.267942+00	36	DK-2026-6E1B24 – Ewenette Munene	3		8	1
225	2026-05-12 14:46:39.048305+00	46	DK-2026-BD4D5B – Ewenette Munene	3		8	1
226	2026-05-12 14:46:39.048353+00	45	DK-2026-696EEE – Ewenette Munene	3		8	1
227	2026-05-12 14:46:39.048405+00	35	DK-2026-3CC33C – Ewenette Munene	3		8	1
228	2026-05-12 14:46:39.048427+00	32	DK-2026-21F9F2 – Ewenette Munene	3		8	1
229	2026-05-12 14:46:39.048445+00	28	DK-2026-75DF56 – Ewenette Munene	3		8	1
230	2026-05-12 14:53:13.070425+00	48	DK-2026-C74BE7 – Ewenette Munene	3		8	1
231	2026-05-12 14:53:13.070505+00	38	DK-2026-9640E6 – Ewenette Munene	3		8	1
232	2026-05-12 14:53:13.070546+00	31	DK-2026-6ABFDE – Ewenette Munene	3		8	1
233	2026-05-12 14:53:13.070594+00	30	DK-2026-3F97CD – Ewenette Munene	3		8	1
234	2026-05-12 14:53:13.070648+00	29	DK-2026-EE60F5 – Ewenette Munene	3		8	1
235	2026-05-12 14:53:13.070694+00	27	DK-2026-E86DCD – Ewenette Munene	3		8	1
236	2026-05-12 15:00:28.584946+00	52	DK-2026-7A0BF6 – Ewenette Munene	3		8	1
237	2026-05-12 18:34:35.557747+00	53	DK-2026-07CFC0 – Ewenette Munene	3		8	1
238	2026-05-12 18:34:35.557812+00	51	DK-2026-011DD5 – Ewenette Munene	3		8	1
239	2026-05-12 18:34:35.557846+00	50	DK-2026-FD850D – Ewenette Munene	3		8	1
240	2026-05-12 18:34:35.557907+00	49	DK-2026-2632BD – Ewenette Munene	3		8	1
241	2026-05-12 18:34:35.557939+00	47	DK-2026-9C6780 – Ewenette Munene	3		8	1
242	2026-05-12 18:34:35.557969+00	39	DK-2026-6B5220 – Ewenette Munene	3		8	1
243	2026-05-12 18:34:35.557998+00	34	DK-2026-2EEC7F – Ewenette Munene	3		8	1
244	2026-05-12 18:34:35.558023+00	33	DK-2026-4D90C0 – Ewenette Munene	3		8	1
245	2026-05-12 19:01:07.320232+00	57	DK-2026-A56E26 – Ewenette Munene	3		8	1
246	2026-05-12 19:01:07.32027+00	56	DK-2026-CE6C8E – Ewenette Munene	3		8	1
247	2026-05-12 19:01:07.320293+00	55	DK-2026-2950F0 – Ewenette Munene	3		8	1
248	2026-05-12 19:01:07.320319+00	54	DK-2026-CD3BDE – Ewenette Munene	3		8	1
249	2026-05-14 11:09:38.829985+00	59	DK-2026-BE2E4A – Ewenette Munene	3		8	1
250	2026-05-14 11:09:38.830073+00	58	DK-2026-807B61 – Ewenette Munene	3		8	1
251	2026-05-14 11:12:48.967603+00	29	Test	1	[{"added": {}}]	7	1
252	2026-05-14 11:13:17.585134+00	29	Test	2	[{"changed": {"fields": ["Order"]}}]	7	1
253	2026-05-14 11:15:26.04425+00	29	Test	2	[{"changed": {"fields": ["Price usd", "Price kes", "Price eur"]}}]	7	1
254	2026-05-14 11:47:04.508076+00	61	DK-2026-41D9BF – Ewenette Munene	3		8	1
255	2026-05-14 11:47:04.508135+00	60	DK-2026-2506B5 – Ewenette Munene	3		8	1
256	2026-05-14 11:47:15.911217+00	29	Test	3		7	1
257	2026-05-15 13:23:42.49026+00	62	DK-2026-3B8487 – Ewenette Munene	3		8	1
258	2026-05-15 13:35:19.895498+00	64	DK-2026-7E09B9 – Ewenette Munene	3		8	1
259	2026-05-15 13:35:19.895552+00	63	DK-2026-2B4AB8 – Ewenette Munene	3		8	1
260	2026-05-15 13:49:41.233992+00	67	DK-2026-C1DDE5 – Ewenette Munene	3		8	1
261	2026-05-15 13:49:41.234093+00	65	DK-2026-D8F3AA – Ewenette Munene	3		8	1
262	2026-05-15 13:50:04.914933+00	68	DK-2026-C3301D – Ewenette Munene	3		8	1
263	2026-05-16 08:34:51.76027+00	100	DK-2026-336204 – Ewenette Munene	3		8	1
264	2026-05-16 08:34:51.760324+00	98	DK-2026-CDF378 – Ewenette Munene	3		8	1
265	2026-05-16 08:34:51.760349+00	97	DK-2026-3D078E – Ewenette Munene	3		8	1
266	2026-05-16 08:34:51.760369+00	96	DK-2026-08185F – Ewenette Munene	3		8	1
267	2026-05-16 08:34:51.760387+00	95	DK-2026-307CC3 – Ewenette Munene	3		8	1
268	2026-05-16 08:34:51.760404+00	94	DK-2026-850331 – Ewenette Munene	3		8	1
269	2026-05-16 08:34:51.760421+00	93	DK-2026-BBC2B5 – Ewenette Munene	3		8	1
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: munwan
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	auth	user
5	contenttypes	contenttype
6	sessions	session
7	core	vehicle
8	core	booking
9	core	paymentlog
10	core	review
11	core	supportticket
12	core	ratelimitentry
13	core	emailotp
14	core	safaridestination
15	core	safaripricing
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: munwan
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2026-05-02 19:46:53.165483+00
2	auth	0001_initial	2026-05-02 19:46:53.230326+00
3	admin	0001_initial	2026-05-02 19:46:53.255667+00
4	admin	0002_logentry_remove_auto_add	2026-05-02 19:46:53.264349+00
5	admin	0003_logentry_add_action_flag_choices	2026-05-02 19:46:53.271416+00
6	contenttypes	0002_remove_content_type_name	2026-05-02 19:46:53.311341+00
7	auth	0002_alter_permission_name_max_length	2026-05-02 19:46:53.318737+00
8	auth	0003_alter_user_email_max_length	2026-05-02 19:46:53.325929+00
9	auth	0004_alter_user_username_opts	2026-05-02 19:46:53.337717+00
10	auth	0005_alter_user_last_login_null	2026-05-02 19:46:53.349061+00
11	auth	0006_require_contenttypes_0002	2026-05-02 19:46:53.350359+00
12	auth	0007_alter_validators_add_error_messages	2026-05-02 19:46:53.357646+00
13	auth	0008_alter_user_username_max_length	2026-05-02 19:46:53.368301+00
14	auth	0009_alter_user_last_name_max_length	2026-05-02 19:46:53.374976+00
15	auth	0010_alter_group_name_max_length	2026-05-02 19:46:53.385944+00
16	auth	0011_update_proxy_permissions	2026-05-02 19:46:53.39367+00
17	auth	0012_alter_user_first_name_max_length	2026-05-02 19:46:53.402285+00
18	core	0001_initial	2026-05-02 19:46:53.498554+00
19	core	0002_hire_type_choices	2026-05-02 19:46:53.513125+00
20	core	0003_terms_accepted	2026-05-02 19:46:53.527982+00
21	core	0004 simplify hire types	2026-05-02 19:46:53.554642+00
22	core	0005_baby_seat	2026-05-02 19:46:53.566641+00
23	core	0006_payment_reminder_flag	2026-05-02 19:46:53.580617+00
24	sessions	0001_initial	2026-05-02 19:46:53.592686+00
25	core	0007_payment_attempt_at	2026-05-03 08:08:52.846362+00
26	core	0008_email_otp_and_pickup_other	2026-05-03 20:38:31.852065+00
27	core	0009_pickup_choice_rename	2026-05-04 03:53:37.869965+00
28	core	0010_airport_transfer	2026-05-09 07:54:39.175653+00
30	core	0011_merge_0006_payment_reminde_flag_0010_airport_transfer	2026-05-11 11:34:15.301716+00
31	core	0012_safari_destinations	2026-05-11 11:36:54.981241+00
32	core	0013_alter_booking_baby_seat_and_more	2026-05-11 14:01:26.142433+00
33	core	0012_safari_and_remove_long	2026-05-11 23:11:16.053103+00
34	core	0013_booking_parent	2026-05-12 13:49:29.977587+00
35	core	0014_invoice	2026-05-15 12:20:42.230696+00
36	core	0015_company_fields	2026-05-15 16:52:29.186824+00
37	core	0016_company_fields_default	2026-05-15 17:17:10.187307+00
38	core	0017_remove_paypal_payment_method	2026-05-16 08:50:52.362975+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: munwan
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
3xyrewp3ogdx0vv56b92kh6hlrny8vtn	.eJxVjr0OgjAUhd-lsyEttLTX0cTZybnpvbcVglADMhnf3WIYdDrJ-flyXsKH9dn5dYmz71kchVLi8GtioCFOW0J5jtU32L2lOo-hv1_maylOYYynvfsH6MLSlXUTGCFZtk5FrNklqaOTGjWzgrYl26JBNo6MIavJaJmgRpKYLGiGpkAfhd1PN485D5tufwHeH_NHQS4:1wOK1w:W22yb1IYbKOkFP5IaU-OOrJ1wEhryJMorS7xwFS6eX8	2026-05-30 18:46:32.051679+00
0h7afna45wfr49poijdsnggcbl7avh4i	.eJxVjjsLwjAUhf9LZilJm6ej4OzkHHLvTWypbaS1k_jfTaSDTgfO4-O8mA_bs_fbGhc_EDsyIdjh14SAY5xrgnmJzTfYvbU5T2G4X5ZrKc5hiqe9-wfow9qXdRcIXDJkrIjQkk1cRsslSCLhtEajQQEpi0qhkagkT64F5JCMk-S6An0U9jDfPOQ8Vq1_DX9_APMvQSM:1wOK5G:oR80I-3cz4Sc6CMzV2IUVOz4F4lh5TP5aI26hDLYqtI	2026-05-30 18:49:58.43266+00
19j7pz0czgck9iz1rzv6s9df5tssgh8c	eyJvdHBfdXNlcl9wayI6NX0:1wJdp2:9UE3NqXjX5sxi2IU-XNJcCqK3tt6sm3ts6NTaPB2Isw	2026-05-17 20:53:52.014665+00
kkvjrj7l0kgbsvuhk542pn8jsl4ld93e	.eJxVjjsLwjAUhf9LZilJm6ej4OzkHHLvTWypbaS1k_jfTaSDTgfO4-O8mA_bs_fbGhc_EDsyIdjh14SAY5xrgnmJzTfYvbU5T2G4X5ZrKc5hiqe9-wfow9qXdRcIXDJkrIjQkk1cRsslSCLhtEajQQEpi0qhkagkT64F5JCMk-S6An0U9jDfPOQ8Vq1_DX9_APMvQSM:1wOBSq:K7UxDjN_rkNFaWAL5WvjW0_hb8vFCgH0NXQcz2D-3-w	2026-05-30 09:37:44.632398+00
3epl2lhv5833qked0p1lb1i0r23bn6h5	.eJxVj7sOwjAMRf-lM1RpmycbCCYGJuYoThwalSaoDwkJ8e-kqANMlu49PpZfhTbz1Op5xEEHV-yKqio2vyEY22FcGpsGLL_Fmo3lqTfhfhmuGYymx8PK_glaM7Z5uzEOlBdOyAqhdtITipJQoM5VinMrODBwTFrGrKCWUeJVDZaAF4o61WQpPieMY0hRJ68H9Nl6PG9rUvMtk2rPWWYe-X6INw0pdctcfhLk_QHE3EvD:1wOJWx:55ipLw83w8WmJmwIpdblpsHu7JtSIXqhlsM8J8P4fP8	2026-05-30 18:14:31.969487+00
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: munwan
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: munwan
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: munwan
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 60, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: munwan
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: munwan
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 11, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: munwan
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: core_booking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: munwan
--

SELECT pg_catalog.setval('public.core_booking_id_seq', 100, true);


--
-- Name: core_booking_safari_destinations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: munwan
--

SELECT pg_catalog.setval('public.core_booking_safari_destinations_id_seq', 6, true);


--
-- Name: core_emailotp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: munwan
--

SELECT pg_catalog.setval('public.core_emailotp_id_seq', 6, true);


--
-- Name: core_paymentlog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: munwan
--

SELECT pg_catalog.setval('public.core_paymentlog_id_seq', 33, true);


--
-- Name: core_ratelimitentry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: munwan
--

SELECT pg_catalog.setval('public.core_ratelimitentry_id_seq', 17, true);


--
-- Name: core_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: munwan
--

SELECT pg_catalog.setval('public.core_review_id_seq', 6, true);


--
-- Name: core_safaridestination_id_seq; Type: SEQUENCE SET; Schema: public; Owner: munwan
--

SELECT pg_catalog.setval('public.core_safaridestination_id_seq', 10, true);


--
-- Name: core_safaripricing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: munwan
--

SELECT pg_catalog.setval('public.core_safaripricing_id_seq', 30, true);


--
-- Name: core_supportticket_id_seq; Type: SEQUENCE SET; Schema: public; Owner: munwan
--

SELECT pg_catalog.setval('public.core_supportticket_id_seq', 2, true);


--
-- Name: core_vehicle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: munwan
--

SELECT pg_catalog.setval('public.core_vehicle_id_seq', 29, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: munwan
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 269, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: munwan
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 15, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: munwan
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 38, true);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: core_booking core_booking_pkey; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_booking
    ADD CONSTRAINT core_booking_pkey PRIMARY KEY (id);


--
-- Name: core_booking core_booking_reference_key; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_booking
    ADD CONSTRAINT core_booking_reference_key UNIQUE (reference);


--
-- Name: core_booking_safari_destinations core_booking_safari_dest_booking_id_safaridestina_af8d85b2_uniq; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_booking_safari_destinations
    ADD CONSTRAINT core_booking_safari_dest_booking_id_safaridestina_af8d85b2_uniq UNIQUE (booking_id, safaridestination_id);


--
-- Name: core_booking_safari_destinations core_booking_safari_destinations_pkey; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_booking_safari_destinations
    ADD CONSTRAINT core_booking_safari_destinations_pkey PRIMARY KEY (id);


--
-- Name: core_emailotp core_emailotp_pkey; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_emailotp
    ADD CONSTRAINT core_emailotp_pkey PRIMARY KEY (id);


--
-- Name: core_paymentlog core_paymentlog_pkey; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_paymentlog
    ADD CONSTRAINT core_paymentlog_pkey PRIMARY KEY (id);


--
-- Name: core_ratelimitentry core_ratelimitentry_ip_address_action_fe93a6a4_uniq; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_ratelimitentry
    ADD CONSTRAINT core_ratelimitentry_ip_address_action_fe93a6a4_uniq UNIQUE (ip_address, action);


--
-- Name: core_ratelimitentry core_ratelimitentry_pkey; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_ratelimitentry
    ADD CONSTRAINT core_ratelimitentry_pkey PRIMARY KEY (id);


--
-- Name: core_review core_review_booking_id_key; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_review
    ADD CONSTRAINT core_review_booking_id_key UNIQUE (booking_id);


--
-- Name: core_review core_review_pkey; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_review
    ADD CONSTRAINT core_review_pkey PRIMARY KEY (id);


--
-- Name: core_safaridestination core_safaridestination_name_key; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_safaridestination
    ADD CONSTRAINT core_safaridestination_name_key UNIQUE (name);


--
-- Name: core_safaridestination core_safaridestination_pkey; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_safaridestination
    ADD CONSTRAINT core_safaridestination_pkey PRIMARY KEY (id);


--
-- Name: core_safaridestination core_safaridestination_slug_key; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_safaridestination
    ADD CONSTRAINT core_safaridestination_slug_key UNIQUE (slug);


--
-- Name: core_safaripricing core_safaripricing_destination_id_vehicle_id_e1009c8e_uniq; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_safaripricing
    ADD CONSTRAINT core_safaripricing_destination_id_vehicle_id_e1009c8e_uniq UNIQUE (destination_id, vehicle_id);


--
-- Name: core_safaripricing core_safaripricing_pkey; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_safaripricing
    ADD CONSTRAINT core_safaripricing_pkey PRIMARY KEY (id);


--
-- Name: core_supportticket core_supportticket_pkey; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_supportticket
    ADD CONSTRAINT core_supportticket_pkey PRIMARY KEY (id);


--
-- Name: core_vehicle core_vehicle_pkey; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_vehicle
    ADD CONSTRAINT core_vehicle_pkey PRIMARY KEY (id);


--
-- Name: core_vehicle core_vehicle_slug_key; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_vehicle
    ADD CONSTRAINT core_vehicle_slug_key UNIQUE (slug);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: core_booking_invoice_number_a692a043; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX core_booking_invoice_number_a692a043 ON public.core_booking USING btree (invoice_number);


--
-- Name: core_booking_invoice_number_a692a043_like; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX core_booking_invoice_number_a692a043_like ON public.core_booking USING btree (invoice_number varchar_pattern_ops);


--
-- Name: core_booking_parent_booking_id_33499372; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX core_booking_parent_booking_id_33499372 ON public.core_booking USING btree (parent_booking_id);


--
-- Name: core_booking_reference_9109c71f_like; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX core_booking_reference_9109c71f_like ON public.core_booking USING btree (reference varchar_pattern_ops);


--
-- Name: core_booking_safari_destinations_booking_id_dc125a7e; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX core_booking_safari_destinations_booking_id_dc125a7e ON public.core_booking_safari_destinations USING btree (booking_id);


--
-- Name: core_booking_safari_destinations_safaridestination_id_f431b6aa; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX core_booking_safari_destinations_safaridestination_id_f431b6aa ON public.core_booking_safari_destinations USING btree (safaridestination_id);


--
-- Name: core_booking_user_id_55d9bfa8; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX core_booking_user_id_55d9bfa8 ON public.core_booking USING btree (user_id);


--
-- Name: core_booking_vehicle_id_ca3eca18; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX core_booking_vehicle_id_ca3eca18 ON public.core_booking USING btree (vehicle_id);


--
-- Name: core_emailotp_email_20c81e6d; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX core_emailotp_email_20c81e6d ON public.core_emailotp USING btree (email);


--
-- Name: core_emailotp_email_20c81e6d_like; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX core_emailotp_email_20c81e6d_like ON public.core_emailotp USING btree (email varchar_pattern_ops);


--
-- Name: core_emailotp_user_id_fc31491f; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX core_emailotp_user_id_fc31491f ON public.core_emailotp USING btree (user_id);


--
-- Name: core_paymentlog_booking_id_8ce3d5e2; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX core_paymentlog_booking_id_8ce3d5e2 ON public.core_paymentlog USING btree (booking_id);


--
-- Name: core_safaridestination_name_da9a987b_like; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX core_safaridestination_name_da9a987b_like ON public.core_safaridestination USING btree (name varchar_pattern_ops);


--
-- Name: core_safaridestination_slug_fb4e83b3_like; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX core_safaridestination_slug_fb4e83b3_like ON public.core_safaridestination USING btree (slug varchar_pattern_ops);


--
-- Name: core_safaripricing_destination_id_52877daa; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX core_safaripricing_destination_id_52877daa ON public.core_safaripricing USING btree (destination_id);


--
-- Name: core_safaripricing_vehicle_id_f8424545; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX core_safaripricing_vehicle_id_f8424545 ON public.core_safaripricing USING btree (vehicle_id);


--
-- Name: core_vehicle_slug_2bec56e2_like; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX core_vehicle_slug_2bec56e2_like ON public.core_vehicle USING btree (slug varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: munwan
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_booking core_booking_parent_booking_id_33499372_fk_core_booking_id; Type: FK CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_booking
    ADD CONSTRAINT core_booking_parent_booking_id_33499372_fk_core_booking_id FOREIGN KEY (parent_booking_id) REFERENCES public.core_booking(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_booking_safari_destinations core_booking_safari__booking_id_dc125a7e_fk_core_book; Type: FK CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_booking_safari_destinations
    ADD CONSTRAINT core_booking_safari__booking_id_dc125a7e_fk_core_book FOREIGN KEY (booking_id) REFERENCES public.core_booking(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_booking_safari_destinations core_booking_safari_desti_safaridestination_id_f431b6aa_fk; Type: FK CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_booking_safari_destinations
    ADD CONSTRAINT core_booking_safari_desti_safaridestination_id_f431b6aa_fk FOREIGN KEY (safaridestination_id) REFERENCES public.core_safaridestination(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_booking core_booking_user_id_55d9bfa8_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_booking
    ADD CONSTRAINT core_booking_user_id_55d9bfa8_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_booking core_booking_vehicle_id_ca3eca18_fk_core_vehicle_id; Type: FK CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_booking
    ADD CONSTRAINT core_booking_vehicle_id_ca3eca18_fk_core_vehicle_id FOREIGN KEY (vehicle_id) REFERENCES public.core_vehicle(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_emailotp core_emailotp_user_id_fc31491f_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_emailotp
    ADD CONSTRAINT core_emailotp_user_id_fc31491f_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_paymentlog core_paymentlog_booking_id_8ce3d5e2_fk_core_booking_id; Type: FK CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_paymentlog
    ADD CONSTRAINT core_paymentlog_booking_id_8ce3d5e2_fk_core_booking_id FOREIGN KEY (booking_id) REFERENCES public.core_booking(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_review core_review_booking_id_bd813940_fk_core_booking_id; Type: FK CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_review
    ADD CONSTRAINT core_review_booking_id_bd813940_fk_core_booking_id FOREIGN KEY (booking_id) REFERENCES public.core_booking(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_safaripricing core_safaripricing_destination_id_52877daa_fk; Type: FK CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_safaripricing
    ADD CONSTRAINT core_safaripricing_destination_id_52877daa_fk FOREIGN KEY (destination_id) REFERENCES public.core_safaridestination(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_safaripricing core_safaripricing_vehicle_id_f8424545_fk_core_vehicle_id; Type: FK CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.core_safaripricing
    ADD CONSTRAINT core_safaripricing_vehicle_id_f8424545_fk_core_vehicle_id FOREIGN KEY (vehicle_id) REFERENCES public.core_vehicle(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: munwan
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

\unrestrict BD9TOnf9hZYZwMK5j2mIn2U5UkiWeyeAVRPWvbwj4rkuDr2bHYrsMTnmP59oCCP

